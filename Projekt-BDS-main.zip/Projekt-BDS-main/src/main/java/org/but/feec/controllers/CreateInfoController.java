package org.but.feec.controllers;

public class CreateInfoController {


}
